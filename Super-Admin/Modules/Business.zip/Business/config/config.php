<?php

return [
    'name' => 'Business',
];
