@extends('layouts.business.master')

@section('title')
    {{ __('Income List') }}
@endsection

@section('main_content')
    <div class="erp-table-section">
        <div class="container-fluid">
            <div class="card">
                <div class="card-bodys">
                    <div class="table-header p-16">
                        <h4>{{ __('Income List') }}</h4>
                        @usercan('incomes.create')
                        <a type="button" href="#incomes-create-modal" data-bs-toggle="modal"
                            class="add-order-btn rounded-2 {{ Route::is('business.incomes.create') ? 'active' : '' }}"
                            class="btn btn-primary"><i class="fas fa-plus-circle me-1"></i>{{ __('Add new') }}</a>
                        @endusercan
                    </div>

                    <div class="table-top-form p-16-0">
                        <form action="{{ route('business.incomes.filter') }}" method="post" class="filter-form"
                            table="#incomes-data">
                            @csrf
                            <div class="table-top-left d-flex gap-3 margin-lr-16 flex-wrap">

                                <div class="gpt-up-down-arrow position-relative">
                                    <select name="per_page" class="form-control">
                                        <option value="10">{{ __('Show- 10') }}</option>
                                        <option value="25">{{ __('Show- 25') }}</option>
                                        <option value="50">{{ __('Show- 50') }}</option>
                                        <option value="100">{{ __('Show- 100') }}</option>
                                    </select>
                                    <span></span>
                                </div>

                                @if(auth()->user()->accessToMultiBranch())
                                <div class="table-search position-relative">
                                    <div class="gpt-up-down-arrow position-relative">
                                        <select name="branch_id" class="form-control">
                                            <option value="">{{ __('Select Branch') }}</option>
                                            @foreach ($branches as $branch)
                                                <option value="{{ $branch->id }}">{{ $branch->name }}</option>
                                            @endforeach
                                        </select>
                                        <span></span>
                                    </div>
                                </div>
                                @endif

                                <div class="table-search position-relative">
                                    <input type="text" name="search" class="form-control"
                                        placeholder="{{ __('Search...') }}">
                                    <span class="position-absolute">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M14.582 14.582L18.332 18.332" stroke="#4D4D4D" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round"/>
                                            <path d="M16.668 9.16797C16.668 5.02584 13.3101 1.66797 9.16797 1.66797C5.02584 1.66797 1.66797 5.02584 1.66797 9.16797C1.66797 13.3101 5.02584 16.668 9.16797 16.668C13.3101 16.668 16.668 13.3101 16.668 9.16797Z" stroke="#4D4D4D" stroke-width="1.25" stroke-linejoin="round"/>
                                            </svg>

                                    </span>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="delete-item delete-show d-none">
                    <div class="delete-item-show">
                        <p class="fw-bold"><span class="selected-count"></span> {{ __('items show') }}</p>
                        <button data-bs-toggle="modal" class="trigger-modal" data-bs-target="#multi-delete-modal" data-url="{{ route('business.incomes.delete-all') }}">{{ __('Delete') }}</button>
                    </div>
                </div>

                <div class="responsive-table m-0">
                    <table class="table" id="datatable">
                        <thead>
                            <tr>
                                @usercan('incomes.delete')
                                <th class="w-60">
                                    <div class="d-flex align-items-center gap-3">
                                        <input type="checkbox" class="select-all-delete  multi-delete">
                                    </div>
                                </th>
                                @endusercan
                                <th>{{ __('SL') }}.</th>
                                @if(auth()->user()->accessToMultiBranch())
                                <th class="text-start">{{ __('Branch') }}</th>
                                @endif
                                <th class="text-start">{{ __('Amount') }}</th>
                                <th class="text-start">{{ __('Category') }}</th>
                                <th class="text-start">{{ __('Income For') }}</th>
                                <th class="text-start">{{ __('Payment Type') }}</th>
                                <th class="text-start">{{ __('Reference Number') }}</th>
                                <th class="text-start">{{ __('Income Date') }}</th>
                                <th>{{ __('Action') }}</th>
                            </tr>
                        </thead>
                        <tbody id="incomes-data">
                            @include('business::incomes.datas')
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    {{ $incomes->links('vendor.pagination.bootstrap-5') }}
                </div>
            </div>
        </div>
    </div>
@endsection

@push('modal')
    @include('business::component.delete-modal')
    @include('business::incomes.create')
    @include('business::incomes.edit')
@endpush
