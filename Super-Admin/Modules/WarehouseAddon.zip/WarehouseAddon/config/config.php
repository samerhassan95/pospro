<?php

return [
    'name' => 'WarehouseAddon',
];
